<?php



    class ContaCorrente{
        public $titula;
        public $agencia;
        public $numero;
        public $saldo; 

        public function __constructor($titula, $agencia, $numero, $saldo){

            $this->$titular = $titula;
            $this->$agencia = $agencia;
            $this->$numero = $numero;
            $this->$saldo = $saldo;

        }

        public function sacar($valor){
            $this->saldo = $this->saldo - $valor;
        }

        public function depositar($valor){
            $this->saldo = $this->saldo + $valor;
        }

    }

?>