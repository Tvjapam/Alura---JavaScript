<?php

    require "ContaCorrente.php";

    $contaJoao = new ContaCorrente();
?>